package com.example.calculadoraekemplo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;



public class MainActivity extends AppCompatActivity {
    TextView tvResultado;
    float numero1 = 0.0f;
    float numero2 = 0.0f;
    String operacion = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvResultado = findViewById(R.id.tdResultado);
        }

    public void EscribirSiete(View view){
        float valor = Float.parseFloat(tvResultado.getText().toString());
        if (valor == 0.0f) {
            tvResultado.setText("7");
        }else{
            tvResultado.setText(tvResultado.getText() + "7");
        }

    }
    public void EscribirOcho(View view){
        float valor = Float.parseFloat(tvResultado.getText().toString());
        if (valor == 0.0f) {
            tvResultado.setText("7");
        }else{
            tvResultado.setText(tvResultado.getText() + "8");
        }

    }

}